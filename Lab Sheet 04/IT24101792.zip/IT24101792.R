getwd()
setwd("C:\\Users\\IT24101792\\Desktop\\IT24101792")

#Question 1
branch_data <- read.table("C:\\Users\\IT24101792\\Desktop\\IT24101792\\Exercise.txt", header=TRUE, sep=",")
head(branch_data)

#Question 2
str(branch_data)


#Question 3
boxplot(branch_data$Sales_X1, main="Box plot for Sales", ylab = "Sales")

#Question 4 
fivenum(branch_data$Advertising_X2)  

IQR(branch_data$Advertising_X2)

#Question 5 
find_outliers <- function(x){
  q1 <- quantile(x , 0.25)
  q3 <- quantile(x , 0.75)
  IQR_value <- q3 - q1
  lower <- q1 - 1.5 * IQR_value
  upper <- q3 + 1.5 * IQR_value
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

find_outliers(branch_data$Years_X3)